import type { Express } from "express";
import { createServer, type Server } from "http";
import Stripe from "stripe";
import { storage } from "./storage";
import { setupAuth, isAuthenticated, hashPassword, comparePassword, createUserSession, destroyUserSession } from "./auth";
import { createPaypalOrder, capturePaypalOrder, loadPaypalDefault, isPayPalConfigured } from "./paypal";
import { insertServiceSchema, insertOrderSchema, insertTransactionSchema, insertWhatsappNumberSchema, insertSupportTicketSchema, signupSchema, signinSchema } from "@shared/schema";
import type { AuthenticatedUser } from "./auth";

// Make Stripe optional
const isStripeConfigured = !!process.env.STRIPE_SECRET_KEY;
let stripe: Stripe | null = null;

if (isStripeConfigured) {
  stripe = new Stripe(process.env.STRIPE_SECRET_KEY!, {
    apiVersion: "2025-08-27.basil",
  });
}

export async function registerRoutes(app: Express): Promise<Server> {
  // Auth middleware
  await setupAuth(app);

  // Auth routes
  app.post('/api/auth/signup', async (req, res) => {
    try {
      const validatedData = signupSchema.parse(req.body);
      
      // Check if user already exists
      const existingUser = await storage.getUserByEmail(validatedData.email);
      if (existingUser) {
        return res.status(400).json({ message: "User already exists with this email" });
      }

      // Hash password
      const hashedPassword = await hashPassword(validatedData.password);
      
      // Create user
      const user = await storage.createUser({
        email: validatedData.email,
        password: hashedPassword,
        firstName: validatedData.firstName,
        lastName: validatedData.lastName,
      });

      // Create session
      await createUserSession(req, user);

      // Return user without password
      const { password, ...userWithoutPassword } = user;
      res.json(userWithoutPassword);
    } catch (error: any) {
      console.error("Error creating user:", error);
      res.status(400).json({ message: error.message || "Failed to create user" });
    }
  });

  app.post('/api/auth/signin', async (req, res) => {
    try {
      const validatedData = signinSchema.parse(req.body);
      
      // Find user by email
      const user = await storage.getUserByEmail(validatedData.email);
      if (!user || !user.password) {
        return res.status(401).json({ message: "Invalid email or password" });
      }

      // Compare password
      const isValidPassword = await comparePassword(validatedData.password, user.password);
      if (!isValidPassword) {
        return res.status(401).json({ message: "Invalid email or password" });
      }

      // Create session
      await createUserSession(req, user);

      // Return user without password
      const { password, ...userWithoutPassword } = user;
      res.json(userWithoutPassword);
    } catch (error: any) {
      console.error("Error signing in:", error);
      res.status(400).json({ message: error.message || "Failed to sign in" });
    }
  });

  app.post('/api/auth/logout', async (req, res) => {
    try {
      await destroyUserSession(req);
      res.json({ message: "Logged out successfully" });
    } catch (error) {
      console.error("Error logging out:", error);
      res.status(500).json({ message: "Failed to log out" });
    }
  });

  app.get('/api/auth/user', isAuthenticated, async (req, res) => {
    try {
      const user = req.user as AuthenticatedUser;
      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  // PayPal routes (only if configured)
  if (isPayPalConfigured) {
    app.get("/api/paypal/setup", async (req, res) => {
      await loadPaypalDefault(req, res);
    });

    app.post("/api/paypal/order", async (req, res) => {
      await createPaypalOrder(req, res);
    });

    app.post("/api/paypal/order/:orderID/capture", async (req, res) => {
      await capturePaypalOrder(req, res);
    });
  } else {
    // Provide disabled endpoints when PayPal is not configured
    app.get("/api/paypal/setup", (req, res) => {
      res.status(503).json({ error: "PayPal is not configured" });
    });

    app.post("/api/paypal/order", (req, res) => {
      res.status(503).json({ error: "PayPal is not configured" });
    });

    app.post("/api/paypal/order/:orderID/capture", (req, res) => {
      res.status(503).json({ error: "PayPal is not configured" });
    });
  }

  // Stripe payment route
  app.post("/api/create-payment-intent", isAuthenticated, async (req, res) => {
    try {
      if (!isStripeConfigured || !stripe) {
        return res.status(503).json({ message: "Stripe is not configured" });
      }

      const { amount } = req.body;
      const paymentIntent = await stripe.paymentIntents.create({
        amount: Math.round(amount * 100), // Convert to cents
        currency: "usd",
        metadata: {
          userId: req.user.id,
        },
      });
      res.json({ clientSecret: paymentIntent.client_secret });
    } catch (error: any) {
      res.status(500).json({ message: "Error creating payment intent: " + error.message });
    }
  });

  // Services routes
  app.get("/api/services", async (req, res) => {
    try {
      const services = await storage.getServices();
      res.json(services);
    } catch (error) {
      console.error("Error fetching services:", error);
      res.status(500).json({ message: "Failed to fetch services" });
    }
  });

  app.post("/api/services", isAuthenticated, async (req, res) => {
    try {
      const userId = req.user.id;
      const user = await storage.getUser(userId);
      
      if (!user?.isAdmin) {
        return res.status(403).json({ message: "Admin access required" });
      }

      const validatedData = insertServiceSchema.parse(req.body);
      const service = await storage.createService(validatedData);
      res.json(service);
    } catch (error) {
      console.error("Error creating service:", error);
      res.status(500).json({ message: "Failed to create service" });
    }
  });

  // Orders routes
  app.post("/api/orders", isAuthenticated, async (req, res) => {
    try {
      const userId = req.user.id;
      const user = await storage.getUser(userId);
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      const orderData = { ...req.body, userId };
      const validatedData = insertOrderSchema.parse(orderData);
      
      // Check if user has sufficient balance
      const userBalance = parseFloat(user.balance || "0");
      const orderAmount = parseFloat(validatedData.totalAmount);
      
      if (userBalance < orderAmount) {
        return res.status(400).json({ message: "Insufficient balance" });
      }

      // Create order
      const order = await storage.createOrder(validatedData);
      
      // Deduct from user balance
      const newBalance = (userBalance - orderAmount).toFixed(2);
      await storage.updateUserBalance(userId, newBalance);
      
      // Create transaction record
      await storage.createTransaction({
        userId,
        type: "order_payment",
        amount: validatedData.totalAmount,
        status: "completed",
        description: `Payment for order #${order.id}`,
      });

      res.json(order);
    } catch (error) {
      console.error("Error creating order:", error);
      res.status(500).json({ message: "Failed to create order" });
    }
  });

  app.get("/api/orders", isAuthenticated, async (req, res) => {
    try {
      const userId = req.user.id;
      const orders = await storage.getOrdersByUser(userId);
      res.json(orders);
    } catch (error) {
      console.error("Error fetching orders:", error);
      res.status(500).json({ message: "Failed to fetch orders" });
    }
  });

  // Transactions routes
  app.get("/api/transactions", isAuthenticated, async (req, res) => {
    try {
      const userId = req.user.id;
      const transactions = await storage.getTransactionsByUser(userId);
      res.json(transactions);
    } catch (error) {
      console.error("Error fetching transactions:", error);
      res.status(500).json({ message: "Failed to fetch transactions" });
    }
  });

  app.post("/api/transactions", isAuthenticated, async (req, res) => {
    try {
      const userId = req.user.id;
      const transactionData = { ...req.body, userId };
      const validatedData = insertTransactionSchema.parse(transactionData);
      
      const transaction = await storage.createTransaction(validatedData);
      
      // If it's a deposit, update user balance
      if (validatedData.type === "deposit" && validatedData.status === "completed") {
        const user = await storage.getUser(userId);
        if (user) {
          const currentBalance = parseFloat(user.balance || "0");
          const newBalance = (currentBalance + parseFloat(validatedData.amount)).toFixed(2);
          await storage.updateUserBalance(userId, newBalance);
        }
      }
      
      res.json(transaction);
    } catch (error) {
      console.error("Error creating transaction:", error);
      res.status(500).json({ message: "Failed to create transaction" });
    }
  });

  // WhatsApp numbers routes
  app.post("/api/whatsapp-numbers", isAuthenticated, async (req, res) => {
    try {
      const userId = req.user.id;
      const user = await storage.getUser(userId);
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      const numberData = { ...req.body, userId };
      const validatedData = insertWhatsappNumberSchema.parse(numberData);
      
      // Check if user has sufficient balance
      const userBalance = parseFloat(user.balance || "0");
      const numberPrice = parseFloat(validatedData.price);
      
      if (userBalance < numberPrice) {
        return res.status(400).json({ message: "Insufficient balance" });
      }

      // Create WhatsApp number
      const whatsappNumber = await storage.createWhatsappNumber(validatedData);
      
      // Deduct from user balance
      const newBalance = (userBalance - numberPrice).toFixed(2);
      await storage.updateUserBalance(userId, newBalance);
      
      // Create transaction record
      await storage.createTransaction({
        userId,
        type: "order_payment",
        amount: validatedData.price,
        status: "completed",
        description: `WhatsApp number purchase: ${validatedData.phoneNumber}`,
      });

      res.json(whatsappNumber);
    } catch (error) {
      console.error("Error purchasing WhatsApp number:", error);
      res.status(500).json({ message: "Failed to purchase WhatsApp number" });
    }
  });

  app.get("/api/whatsapp-numbers", isAuthenticated, async (req, res) => {
    try {
      const userId = req.user.id;
      const numbers = await storage.getWhatsappNumbersByUser(userId);
      res.json(numbers);
    } catch (error) {
      console.error("Error fetching WhatsApp numbers:", error);
      res.status(500).json({ message: "Failed to fetch WhatsApp numbers" });
    }
  });

  // Support tickets routes
  app.post("/api/support-tickets", isAuthenticated, async (req, res) => {
    try {
      const userId = req.user.id;
      const ticketData = { ...req.body, userId };
      const validatedData = insertSupportTicketSchema.parse(ticketData);
      
      const ticket = await storage.createSupportTicket(validatedData);
      res.json(ticket);
    } catch (error) {
      console.error("Error creating support ticket:", error);
      res.status(500).json({ message: "Failed to create support ticket" });
    }
  });

  app.get("/api/support-tickets", isAuthenticated, async (req, res) => {
    try {
      const userId = req.user.id;
      const tickets = await storage.getSupportTicketsByUser(userId);
      res.json(tickets);
    } catch (error) {
      console.error("Error fetching support tickets:", error);
      res.status(500).json({ message: "Failed to fetch support tickets" });
    }
  });

  // Admin routes
  app.get("/api/admin/stats", isAuthenticated, async (req, res) => {
    try {
      const userId = req.user.id;
      const user = await storage.getUser(userId);
      
      if (!user?.isAdmin) {
        return res.status(403).json({ message: "Admin access required" });
      }

      const stats = await storage.getAdminStats();
      res.json(stats);
    } catch (error) {
      console.error("Error fetching admin stats:", error);
      res.status(500).json({ message: "Failed to fetch admin stats" });
    }
  });

  app.get("/api/admin/users", isAuthenticated, async (req, res) => {
    try {
      const userId = req.user.id;
      const user = await storage.getUser(userId);
      
      if (!user?.isAdmin) {
        return res.status(403).json({ message: "Admin access required" });
      }

      const users = await storage.getAllUsers();
      res.json(users);
    } catch (error) {
      console.error("Error fetching users:", error);
      res.status(500).json({ message: "Failed to fetch users" });
    }
  });

  app.get("/api/admin/orders", isAuthenticated, async (req, res) => {
    try {
      const userId = req.user.id;
      const user = await storage.getUser(userId);
      
      if (!user?.isAdmin) {
        return res.status(403).json({ message: "Admin access required" });
      }

      const orders = await storage.getAllOrders();
      res.json(orders);
    } catch (error) {
      console.error("Error fetching all orders:", error);
      res.status(500).json({ message: "Failed to fetch orders" });
    }
  });

  app.get("/api/admin/support-tickets", isAuthenticated, async (req, res) => {
    try {
      const userId = req.user.id;
      const user = await storage.getUser(userId);
      
      if (!user?.isAdmin) {
        return res.status(403).json({ message: "Admin access required" });
      }

      const tickets = await storage.getAllSupportTickets();
      res.json(tickets);
    } catch (error) {
      console.error("Error fetching support tickets:", error);
      res.status(500).json({ message: "Failed to fetch support tickets" });
    }
  });

  // Update order status (admin only)
  app.patch("/api/admin/orders/:id/status", isAuthenticated, async (req, res) => {
    try {
      const userId = req.user.id;
      const user = await storage.getUser(userId);
      
      if (!user?.isAdmin) {
        return res.status(403).json({ message: "Admin access required" });
      }

      const { id } = req.params;
      const { status } = req.body;
      
      const order = await storage.updateOrderStatus(id, status);
      res.json(order);
    } catch (error) {
      console.error("Error updating order status:", error);
      res.status(500).json({ message: "Failed to update order status" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
