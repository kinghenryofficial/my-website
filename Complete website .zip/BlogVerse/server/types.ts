// Authentication types for manual auth system

export interface AuthenticatedUser {
  id: string;
  email: string;
  firstName: string;
  lastName: string;
  profileImageUrl?: string;
  balance: string;
  isAdmin: boolean;
}

// Extend Express User to include auth properties
declare global {
  namespace Express {
    interface User extends AuthenticatedUser {}
  }
}