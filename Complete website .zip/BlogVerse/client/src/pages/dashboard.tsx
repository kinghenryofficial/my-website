import { useEffect, useState } from "react";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import { apiRequest } from "@/lib/queryClient";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { LoadingPage, Loading } from "@/components/ui/loading";
import type { Service, Order, Transaction, WhatsappNumber, SupportTicket, InsertOrder, InsertTransaction, InsertWhatsappNumber, InsertSupportTicket } from "@shared/schema";


export default function Dashboard() {
  const { user, isLoading, isAuthenticated } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [selectedService, setSelectedService] = useState<Service | null>(null);
  const [orderModalOpen, setOrderModalOpen] = useState(false);
  const [addFundsModalOpen, setAddFundsModalOpen] = useState(false);
  const [whatsappModalOpen, setWhatsappModalOpen] = useState(false);
  const [supportModalOpen, setSupportModalOpen] = useState(false);

  // Redirect to login if not authenticated
  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  // Fetch data
  const { data: services, isLoading: servicesLoading } = useQuery<Service[]>({
    queryKey: ["/api/services"],
    enabled: isAuthenticated,
  });

  const { data: orders, isLoading: ordersLoading } = useQuery<Order[]>({
    queryKey: ["/api/orders"],
    enabled: isAuthenticated,
  });

  const { data: transactions, isLoading: transactionsLoading } = useQuery<Transaction[]>({
    queryKey: ["/api/transactions"],
    enabled: isAuthenticated,
  });

  const { data: whatsappNumbers, isLoading: whatsappLoading } = useQuery<WhatsappNumber[]>({
    queryKey: ["/api/whatsapp-numbers"],
    enabled: isAuthenticated,
  });

  const { data: supportTickets, isLoading: supportLoading } = useQuery<SupportTicket[]>({
    queryKey: ["/api/support-tickets"],
    enabled: isAuthenticated,
  });

  // Mutations
  const createOrderMutation = useMutation({
    mutationFn: async (orderData: Partial<InsertOrder>) => {
      const response = await apiRequest("POST", "/api/orders", orderData);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Order placed successfully!",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/orders"] });
      queryClient.invalidateQueries({ queryKey: ["/api/auth/user"] });
      setOrderModalOpen(false);
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: error.message || "Failed to place order",
        variant: "destructive",
      });
    },
  });

  const addFundsMutation = useMutation({
    mutationFn: async (transactionData: Partial<InsertTransaction>) => {
      const response = await apiRequest("POST", "/api/transactions", transactionData);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Funds added successfully!",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/transactions"] });
      queryClient.invalidateQueries({ queryKey: ["/api/auth/user"] });
      setAddFundsModalOpen(false);
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: error.message || "Failed to add funds",
        variant: "destructive",
      });
    },
  });

  const purchaseWhatsappMutation = useMutation({
    mutationFn: async (numberData: Partial<InsertWhatsappNumber>) => {
      const response = await apiRequest("POST", "/api/whatsapp-numbers", numberData);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "WhatsApp number purchased successfully!",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/whatsapp-numbers"] });
      queryClient.invalidateQueries({ queryKey: ["/api/auth/user"] });
      setWhatsappModalOpen(false);
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: error.message || "Failed to purchase number",
        variant: "destructive",
      });
    },
  });

  const createSupportTicketMutation = useMutation({
    mutationFn: async (ticketData: Partial<InsertSupportTicket>) => {
      const response = await apiRequest("POST", "/api/support-tickets", ticketData);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Support ticket created successfully!",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/support-tickets"] });
      setSupportModalOpen(false);
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: error.message || "Failed to create support ticket",
        variant: "destructive",
      });
    },
  });

  // Handle forms
  const handleOrderSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedService) return;

    const formData = new FormData(e.target as HTMLFormElement);
    const quantity = parseInt(formData.get("quantity") as string);
    const totalAmount = (parseFloat(selectedService.pricePerUnit) * quantity).toFixed(2);

    createOrderMutation.mutate({
      serviceId: selectedService.id,
      targetUrl: formData.get("targetUrl"),
      quantity,
      totalAmount,
    });
  };

  const handleAddFunds = (e: React.FormEvent) => {
    e.preventDefault();
    const formData = new FormData(e.target as HTMLFormElement);
    const amount = formData.get("amount") as string;

    addFundsMutation.mutate({
      type: "deposit",
      amount,
      paymentMethod: formData.get("paymentMethod"),
      status: "completed",
      description: `Deposit via ${formData.get("paymentMethod")}`,
    });
  };

  const handleWhatsappPurchase = (e: React.FormEvent) => {
    e.preventDefault();
    const formData = new FormData(e.target as HTMLFormElement);
    
    const countryData = JSON.parse(formData.get("country") as string);
    const expiresAt = new Date();
    expiresAt.setDate(expiresAt.getDate() + 30);

    purchaseWhatsappMutation.mutate({
      phoneNumber: `+${countryData.code} ${Math.floor(Math.random() * 9000000000) + 1000000000}`,
      countryCode: countryData.code,
      countryName: countryData.name,
      price: countryData.price,
      expiresAt: expiresAt.toISOString(),
    });
  };

  const handleSupportSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const formData = new FormData(e.target as HTMLFormElement);

    createSupportTicketMutation.mutate({
      subject: formData.get("subject"),
      message: formData.get("message"),
      priority: formData.get("priority"),
      category: formData.get("category"),
      orderId: formData.get("orderId") || null,
    });
  };

  const handleLogout = () => {
    window.location.href = "/api/logout";
  };

  if (isLoading) {
    return <LoadingPage />;
  }

  if (!isAuthenticated || !user) {
    return null;
  }

  const stats = {
    totalOrders: orders?.length || 0,
    pendingOrders: orders?.filter((o: Order) => o.status === "pending").length || 0,
    totalSpent: orders?.reduce((sum: number, o: Order) => sum + parseFloat(o.totalAmount), 0).toFixed(2) || "0.00",
    successRate: orders?.length ? Math.round((orders.filter((o: Order) => o.status === "completed").length / orders.length) * 100) : 100,
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="bg-card border-b border-border px-6 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center">
            <div className="h-8 w-8 bg-primary rounded-lg flex items-center justify-center mr-3">
              <svg className="h-5 w-5 text-primary-foreground" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
              </svg>
            </div>
            <h1 className="text-xl font-semibold text-foreground">SocialBoost Dashboard</h1>
          </div>
          <div className="flex items-center space-x-4">
            <div className="bg-accent text-accent-foreground px-4 py-2 rounded-lg">
              <span className="text-sm font-medium">Balance: ${user.balance || "0.00"}</span>
            </div>
            <div className="flex items-center space-x-3">
              <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center">
                <span className="text-sm font-medium text-primary-foreground">
                  {user.firstName?.charAt(0) || user.email?.charAt(0) || "U"}
                </span>
              </div>
              <span className="text-sm font-medium" data-testid="text-user-name">
                {user.firstName ? `${user.firstName} ${user.lastName || ""}`.trim() : user.email}
              </span>
              <Button variant="ghost" size="sm" onClick={handleLogout} data-testid="button-logout">
                Logout
              </Button>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Tabs defaultValue="overview" className="space-y-8">
          <TabsList className="grid grid-cols-6 w-full">
            <TabsTrigger value="overview" data-testid="tab-overview">Dashboard</TabsTrigger>
            <TabsTrigger value="services" data-testid="tab-services">Services</TabsTrigger>
            <TabsTrigger value="orders" data-testid="tab-orders">Orders</TabsTrigger>
            <TabsTrigger value="wallet" data-testid="tab-wallet">Wallet</TabsTrigger>
            <TabsTrigger value="whatsapp" data-testid="tab-whatsapp">WhatsApp</TabsTrigger>
            <TabsTrigger value="support" data-testid="tab-support">Support</TabsTrigger>
          </TabsList>

          {/* Overview Tab */}
          <TabsContent value="overview" className="space-y-8">
            {/* Stats Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-muted-foreground">Total Orders</p>
                      <p className="text-3xl font-bold text-foreground" data-testid="text-total-orders">{stats.totalOrders}</p>
                    </div>
                    <div className="bg-primary/10 p-3 rounded-full">
                      <svg className="h-6 w-6 text-primary" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z" />
                      </svg>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-muted-foreground">Pending Orders</p>
                      <p className="text-3xl font-bold text-foreground" data-testid="text-pending-orders">{stats.pendingOrders}</p>
                    </div>
                    <div className="bg-amber-500/10 p-3 rounded-full">
                      <svg className="h-6 w-6 text-amber-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                      </svg>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-muted-foreground">Total Spent</p>
                      <p className="text-3xl font-bold text-foreground" data-testid="text-total-spent">${stats.totalSpent}</p>
                    </div>
                    <div className="bg-green-500/10 p-3 rounded-full">
                      <svg className="h-6 w-6 text-green-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1" />
                      </svg>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-muted-foreground">Success Rate</p>
                      <p className="text-3xl font-bold text-foreground" data-testid="text-success-rate">{stats.successRate}%</p>
                    </div>
                    <div className="bg-emerald-500/10 p-3 rounded-full">
                      <svg className="h-6 w-6 text-emerald-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                      </svg>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Quick Actions */}
            <Card>
              <CardHeader>
                <CardTitle>Quick Actions</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                  <Dialog open={addFundsModalOpen} onOpenChange={setAddFundsModalOpen}>
                    <DialogTrigger asChild>
                      <Button variant="outline" className="h-20 flex flex-col" data-testid="button-add-funds">
                        <svg className="h-8 w-8 text-primary mb-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6v6m0 0v6m0-6h6m-6 0H6" />
                        </svg>
                        <span className="text-sm font-medium">Add Funds</span>
                      </Button>
                    </DialogTrigger>
                    <DialogContent>
                      <DialogHeader>
                        <DialogTitle>Add Funds</DialogTitle>
                      </DialogHeader>
                      <form onSubmit={handleAddFunds} className="space-y-4">
                        <div>
                          <Label htmlFor="amount">Amount</Label>
                          <Input id="amount" name="amount" type="number" step="0.01" min="1" required data-testid="input-amount" />
                        </div>
                        <div>
                          <Label htmlFor="paymentMethod">Payment Method</Label>
                          <Select name="paymentMethod" required>
                            <SelectTrigger data-testid="select-payment-method">
                              <SelectValue placeholder="Select payment method" />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="stripe">Credit Card (Stripe)</SelectItem>
                              <SelectItem value="paypal">PayPal</SelectItem>
                              <SelectItem value="crypto">Cryptocurrency</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                        <Button type="submit" disabled={addFundsMutation.isPending} data-testid="button-submit-funds">
                          {addFundsMutation.isPending ? <Loading size="sm" className="mr-2" /> : null}
                          Add Funds
                        </Button>
                      </form>
                    </DialogContent>
                  </Dialog>

                  <Button variant="outline" className="h-20 flex flex-col" onClick={() => document.querySelector('[value="services"]')?.click()} data-testid="button-browse-services">
                    <svg className="h-8 w-8 text-primary mb-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z" />
                    </svg>
                    <span className="text-sm font-medium">Browse Services</span>
                  </Button>

                  <Dialog open={whatsappModalOpen} onOpenChange={setWhatsappModalOpen}>
                    <DialogTrigger asChild>
                      <Button variant="outline" className="h-20 flex flex-col" data-testid="button-whatsapp-numbers">
                        <svg className="h-8 w-8 text-green-500 mb-2" fill="currentColor" viewBox="0 0 24 24">
                          <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893A11.821 11.821 0 0020.885 3.488"/>
                        </svg>
                        <span className="text-sm font-medium">WhatsApp Numbers</span>
                      </Button>
                    </DialogTrigger>
                    <DialogContent>
                      <DialogHeader>
                        <DialogTitle>Purchase WhatsApp Number</DialogTitle>
                      </DialogHeader>
                      <form onSubmit={handleWhatsappPurchase} className="space-y-4">
                        <div>
                          <Label htmlFor="country">Country</Label>
                          <Select name="country" required>
                            <SelectTrigger data-testid="select-country">
                              <SelectValue placeholder="Select country" />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value='{"code":"1","name":"United States","price":"2.50"}'>🇺🇸 United States - $2.50</SelectItem>
                              <SelectItem value='{"code":"44","name":"United Kingdom","price":"3.00"}'>🇬🇧 United Kingdom - $3.00</SelectItem>
                              <SelectItem value='{"code":"1","name":"Canada","price":"2.80"}'>🇨🇦 Canada - $2.80</SelectItem>
                              <SelectItem value='{"code":"49","name":"Germany","price":"2.90"}'>🇩🇪 Germany - $2.90</SelectItem>
                              <SelectItem value='{"code":"33","name":"France","price":"2.70"}'>🇫🇷 France - $2.70</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                        <Button type="submit" disabled={purchaseWhatsappMutation.isPending} data-testid="button-purchase-number">
                          {purchaseWhatsappMutation.isPending ? <Loading size="sm" className="mr-2" /> : null}
                          Purchase Number
                        </Button>
                      </form>
                    </DialogContent>
                  </Dialog>

                  <Dialog open={supportModalOpen} onOpenChange={setSupportModalOpen}>
                    <DialogTrigger asChild>
                      <Button variant="outline" className="h-20 flex flex-col" data-testid="button-support">
                        <svg className="h-8 w-8 text-primary mb-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M18.364 5.636l-3.536 3.536m0 5.656l3.536 3.536M9.172 9.172L5.636 5.636m3.536 9.192L5.636 18.364M12 12h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                        </svg>
                        <span className="text-sm font-medium">Support</span>
                      </Button>
                    </DialogTrigger>
                    <DialogContent className="max-w-2xl">
                      <DialogHeader>
                        <DialogTitle>Create Support Ticket</DialogTitle>
                      </DialogHeader>
                      <form onSubmit={handleSupportSubmit} className="space-y-4">
                        <div className="grid grid-cols-2 gap-4">
                          <div>
                            <Label htmlFor="priority">Priority</Label>
                            <Select name="priority" defaultValue="medium">
                              <SelectTrigger data-testid="select-priority">
                                <SelectValue />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="low">Low</SelectItem>
                                <SelectItem value="medium">Medium</SelectItem>
                                <SelectItem value="high">High</SelectItem>
                                <SelectItem value="urgent">Urgent</SelectItem>
                              </SelectContent>
                            </Select>
                          </div>
                          <div>
                            <Label htmlFor="category">Category</Label>
                            <Select name="category" required>
                              <SelectTrigger data-testid="select-category">
                                <SelectValue placeholder="Select category" />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="order">Order Support</SelectItem>
                                <SelectItem value="payment">Payment Issues</SelectItem>
                                <SelectItem value="account">Account Problems</SelectItem>
                                <SelectItem value="technical">Technical Issues</SelectItem>
                                <SelectItem value="other">Other</SelectItem>
                              </SelectContent>
                            </Select>
                          </div>
                        </div>
                        <div>
                          <Label htmlFor="subject">Subject</Label>
                          <Input id="subject" name="subject" required data-testid="input-subject" />
                        </div>
                        <div>
                          <Label htmlFor="orderId">Order ID (optional)</Label>
                          <Input id="orderId" name="orderId" placeholder="#12345" data-testid="input-order-id" />
                        </div>
                        <div>
                          <Label htmlFor="message">Message</Label>
                          <Textarea id="message" name="message" rows={4} required data-testid="textarea-message" />
                        </div>
                        <Button type="submit" disabled={createSupportTicketMutation.isPending} data-testid="button-submit-ticket">
                          {createSupportTicketMutation.isPending ? <Loading size="sm" className="mr-2" /> : null}
                          Submit Ticket
                        </Button>
                      </form>
                    </DialogContent>
                  </Dialog>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Services Tab */}
          <TabsContent value="services" className="space-y-8">
            <Card>
              <CardHeader>
                <CardTitle>Service Marketplace</CardTitle>
              </CardHeader>
              <CardContent>
                {servicesLoading ? (
                  <div className="flex justify-center py-8">
                    <Loading />
                  </div>
                ) : services && services.length > 0 ? (
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {services.map((service: Service) => (
                      <Card key={service.id} className="hover:shadow-md transition-shadow">
                        <CardContent className="p-6">
                          <div className="flex items-center mb-4">
                            <div className={`h-12 w-12 rounded-lg flex items-center justify-center mr-4 ${
                              service.platform === 'instagram' ? 'bg-gradient-to-r from-purple-500 via-pink-500 to-orange-400' :
                              service.platform === 'tiktok' ? 'bg-black' :
                              service.platform === 'youtube' ? 'bg-red-600' :
                              service.platform === 'whatsapp' ? 'bg-green-500' :
                              'bg-primary'
                            }`}>
                              <svg className="h-6 w-6 text-white" fill="currentColor" viewBox="0 0 24 24">
                                {service.platform === 'instagram' && (
                                  <path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z"/>
                                )}
                                {service.platform === 'tiktok' && (
                                  <path d="M19.59 6.69a4.83 4.83 0 0 1-3.77-4.25V2h-3.45v13.67a2.89 2.89 0 0 1-5.2 1.74 2.89 2.89 0 0 1 2.31-4.64 2.93 2.93 0 0 1 .88.13V9.4a6.84 6.84 0 0 0-1-.05A6.33 6.33 0 0 0 5 20.1a6.34 6.34 0 0 0 10.86-4.43v-7a8.16 8.16 0 0 0 4.77 1.52v-3.4a4.85 4.85 0 0 1-.04-.1z"/>
                                )}
                                {service.platform === 'youtube' && (
                                  <path d="M23.498 6.186a3.016 3.016 0 0 0-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 0 0 .502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 0 0 2.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 0 0 2.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z"/>
                                )}
                              </svg>
                            </div>
                            <div>
                              <h3 className="font-semibold text-foreground">{service.name}</h3>
                              <p className="text-sm text-muted-foreground capitalize">{service.platform} • {service.deliveryTime}</p>
                            </div>
                          </div>
                          <p className="text-muted-foreground mb-4 text-sm">{service.description}</p>
                          <div className="flex items-center justify-between mb-4">
                            <span className="text-2xl font-bold text-foreground">${service.pricePerUnit}</span>
                            <span className="text-sm text-muted-foreground">per {service.minQuantity}</span>
                          </div>
                          <Dialog open={orderModalOpen && selectedService?.id === service.id} onOpenChange={(open) => {
                            setOrderModalOpen(open);
                            if (!open) setSelectedService(null);
                          }}>
                            <DialogTrigger asChild>
                              <Button 
                                className="w-full" 
                                onClick={() => setSelectedService(service)}
                                data-testid={`button-order-${service.platform}`}
                              >
                                Order Now
                              </Button>
                            </DialogTrigger>
                            <DialogContent>
                              <DialogHeader>
                                <DialogTitle>Order {service.name}</DialogTitle>
                              </DialogHeader>
                              <form onSubmit={handleOrderSubmit} className="space-y-4">
                                <div>
                                  <Label htmlFor="targetUrl">Target URL/Username</Label>
                                  <Input 
                                    id="targetUrl" 
                                    name="targetUrl" 
                                    required 
                                    placeholder="https://instagram.com/username or @username"
                                    data-testid="input-target-url"
                                  />
                                </div>
                                <div>
                                  <Label htmlFor="quantity">Quantity</Label>
                                  <Input 
                                    id="quantity" 
                                    name="quantity" 
                                    type="number" 
                                    min={service.minQuantity}
                                    max={service.maxQuantity}
                                    defaultValue={service.minQuantity}
                                    required
                                    data-testid="input-quantity"
                                  />
                                </div>
                                <div className="bg-accent p-4 rounded-lg">
                                  <div className="flex justify-between items-center">
                                    <span className="font-medium">Price per unit:</span>
                                    <span className="font-bold text-primary">${service.pricePerUnit}</span>
                                  </div>
                                  <div className="flex justify-between text-sm text-muted-foreground mt-1">
                                    <span>Your Balance:</span>
                                    <span>${user.balance || "0.00"}</span>
                                  </div>
                                </div>
                                <Button type="submit" disabled={createOrderMutation.isPending} data-testid="button-place-order">
                                  {createOrderMutation.isPending ? <Loading size="sm" className="mr-2" /> : null}
                                  Place Order
                                </Button>
                              </form>
                            </DialogContent>
                          </Dialog>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-8 text-muted-foreground">
                    <p>No services available at the moment.</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Orders Tab */}
          <TabsContent value="orders" className="space-y-8">
            <Card>
              <CardHeader>
                <CardTitle>Order History</CardTitle>
              </CardHeader>
              <CardContent>
                {ordersLoading ? (
                  <div className="flex justify-center py-8">
                    <Loading />
                  </div>
                ) : orders && orders.length > 0 ? (
                  <div className="space-y-4">
                    {orders.map((order: Order) => (
                      <div key={order.id} className="border border-border rounded-lg p-4">
                        <div className="flex items-center justify-between">
                          <div>
                            <p className="font-medium text-foreground" data-testid={`text-order-${order.id}`}>Order #{order.id}</p>
                            <p className="text-sm text-muted-foreground">{order.targetUrl}</p>
                            <p className="text-sm text-muted-foreground">Quantity: {order.quantity}</p>
                          </div>
                          <div className="text-right">
                            <p className="font-semibold text-foreground">${order.totalAmount}</p>
                            <Badge variant={
                              order.status === 'completed' ? 'default' :
                              order.status === 'pending' ? 'secondary' :
                              order.status === 'processing' ? 'outline' :
                              'destructive'
                            } data-testid={`badge-status-${order.id}`}>
                              {order.status}
                            </Badge>
                            <p className="text-xs text-muted-foreground mt-1">
                              {new Date(order.createdAt).toLocaleDateString()}
                            </p>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-8 text-muted-foreground">
                    <p>No orders found. <Button variant="link" onClick={() => document.querySelector('[value="services"]')?.click()}>Browse services</Button> to place your first order.</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Wallet Tab */}
          <TabsContent value="wallet" className="space-y-8">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              <Card>
                <CardHeader>
                  <CardTitle>Account Balance</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-center mb-6">
                    <div className="text-4xl font-bold text-foreground mb-2" data-testid="text-balance">${user.balance || "0.00"}</div>
                    <p className="text-muted-foreground">Available for orders</p>
                  </div>
                  <Dialog open={addFundsModalOpen} onOpenChange={setAddFundsModalOpen}>
                    <DialogTrigger asChild>
                      <Button className="w-full" data-testid="button-add-funds-wallet">Add Funds</Button>
                    </DialogTrigger>
                    <DialogContent>
                      <DialogHeader>
                        <DialogTitle>Add Funds to Wallet</DialogTitle>
                      </DialogHeader>
                      <form onSubmit={handleAddFunds} className="space-y-4">
                        <div>
                          <Label htmlFor="amount">Amount</Label>
                          <Input id="amount" name="amount" type="number" step="0.01" min="1" required data-testid="input-wallet-amount" />
                        </div>
                        <div>
                          <Label htmlFor="paymentMethod">Payment Method</Label>
                          <Select name="paymentMethod" required>
                            <SelectTrigger data-testid="select-wallet-payment-method">
                              <SelectValue placeholder="Select payment method" />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="stripe">Credit Card (Stripe)</SelectItem>
                              <SelectItem value="paypal">PayPal</SelectItem>
                              <SelectItem value="crypto">Cryptocurrency</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                        <Button type="submit" disabled={addFundsMutation.isPending} data-testid="button-submit-wallet-funds">
                          {addFundsMutation.isPending ? <Loading size="sm" className="mr-2" /> : null}
                          Add Funds
                        </Button>
                      </form>
                    </DialogContent>
                  </Dialog>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Transaction History</CardTitle>
                </CardHeader>
                <CardContent>
                  {transactionsLoading ? (
                    <div className="flex justify-center py-4">
                      <Loading size="sm" />
                    </div>
                  ) : transactions && transactions.length > 0 ? (
                    <div className="space-y-3 max-h-80 overflow-y-auto">
                      {transactions.map((transaction: Transaction) => (
                        <div key={transaction.id} className="flex items-center justify-between p-3 rounded-lg hover:bg-muted/50">
                          <div className="flex items-center">
                            <div className={`h-10 w-10 rounded-lg flex items-center justify-center mr-3 ${
                              transaction.type === 'deposit' ? 'bg-green-500/10' : 'bg-destructive/10'
                            }`}>
                              <svg className={`h-5 w-5 ${
                                transaction.type === 'deposit' ? 'text-green-500' : 'text-destructive'
                              }`} fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d={
                                  transaction.type === 'deposit' ? 
                                  "M12 6v6m0 0v6m0-6h6m-6 0H6" : 
                                  "M20 12H4"
                                } />
                              </svg>
                            </div>
                            <div>
                              <div className="font-medium text-foreground" data-testid={`text-transaction-${transaction.id}`}>
                                {transaction.description}
                              </div>
                              <div className="text-sm text-muted-foreground">
                                {new Date(transaction.createdAt).toLocaleDateString()}
                              </div>
                            </div>
                          </div>
                          <div className="text-right">
                            <div className={`font-medium ${
                              transaction.type === 'deposit' ? 'text-green-500' : 'text-destructive'
                            }`}>
                              {transaction.type === 'deposit' ? '+' : '-'}${transaction.amount}
                            </div>
                            <div className="text-sm text-muted-foreground">{transaction.status}</div>
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="text-center py-4 text-muted-foreground">
                      <p>No transactions found.</p>
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* WhatsApp Tab */}
          <TabsContent value="whatsapp" className="space-y-8">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              <Card>
                <CardHeader>
                  <CardTitle>Purchase WhatsApp Number</CardTitle>
                </CardHeader>
                <CardContent>
                  <form onSubmit={handleWhatsappPurchase} className="space-y-4">
                    <div>
                      <Label htmlFor="country">Select Country</Label>
                      <Select name="country" required>
                        <SelectTrigger data-testid="select-whatsapp-country">
                          <SelectValue placeholder="Choose a country..." />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value='{"code":"1","name":"United States","price":"2.50"}'>🇺🇸 United States - $2.50</SelectItem>
                          <SelectItem value='{"code":"44","name":"United Kingdom","price":"3.00"}'>🇬🇧 United Kingdom - $3.00</SelectItem>
                          <SelectItem value='{"code":"1","name":"Canada","price":"2.80"}'>🇨🇦 Canada - $2.80</SelectItem>
                          <SelectItem value='{"code":"49","name":"Germany","price":"2.90"}'>🇩🇪 Germany - $2.90</SelectItem>
                          <SelectItem value='{"code":"33","name":"France","price":"2.70"}'>🇫🇷 France - $2.70</SelectItem>
                          <SelectItem value='{"code":"31","name":"Netherlands","price":"2.60"}'>🇳🇱 Netherlands - $2.60</SelectItem>
                          <SelectItem value='{"code":"91","name":"India","price":"1.50"}'>🇮🇳 India - $1.50</SelectItem>
                          <SelectItem value='{"code":"55","name":"Brazil","price":"2.00"}'>🇧🇷 Brazil - $2.00</SelectItem>
                          <SelectItem value='{"code":"52","name":"Mexico","price":"1.80"}'>🇲🇽 Mexico - $1.80</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="bg-accent p-4 rounded-lg">
                      <p className="text-sm text-muted-foreground mb-2">Rental Duration: 30 days</p>
                      <p className="text-sm text-muted-foreground">Numbers are assigned instantly after payment</p>
                    </div>
                    <Button type="submit" disabled={purchaseWhatsappMutation.isPending} data-testid="button-purchase-whatsapp">
                      {purchaseWhatsappMutation.isPending ? <Loading size="sm" className="mr-2" /> : null}
                      Purchase Number
                    </Button>
                  </form>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>My WhatsApp Numbers</CardTitle>
                </CardHeader>
                <CardContent>
                  {whatsappLoading ? (
                    <div className="flex justify-center py-4">
                      <Loading size="sm" />
                    </div>
                  ) : whatsappNumbers && whatsappNumbers.length > 0 ? (
                    <div className="space-y-4">
                      {whatsappNumbers.map((number: WhatsappNumber) => (
                        <div key={number.id} className="flex items-center justify-between border border-border rounded-lg p-4">
                          <div className="flex items-center">
                            <span className="text-2xl mr-3">
                              {number.countryCode === '1' ? '🇺🇸' :
                               number.countryCode === '44' ? '🇬🇧' :
                               number.countryCode === '49' ? '🇩🇪' :
                               number.countryCode === '33' ? '🇫🇷' :
                               number.countryCode === '31' ? '🇳🇱' :
                               number.countryCode === '91' ? '🇮🇳' :
                               number.countryCode === '55' ? '🇧🇷' :
                               number.countryCode === '52' ? '🇲🇽' : '🌍'}
                            </span>
                            <div>
                              <div className="font-medium text-foreground" data-testid={`text-whatsapp-${number.id}`}>{number.phoneNumber}</div>
                              <div className="text-sm text-muted-foreground">{number.countryName}</div>
                            </div>
                          </div>
                          <div className="text-right">
                            <Badge variant={
                              number.status === 'active' ? 'default' :
                              number.status === 'expired' ? 'destructive' :
                              'secondary'
                            } data-testid={`badge-whatsapp-status-${number.id}`}>
                              {number.status}
                            </Badge>
                            <div className="text-xs text-muted-foreground mt-1">
                              Expires: {new Date(number.expiresAt).toLocaleDateString()}
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="text-center py-8 text-muted-foreground">
                      <svg className="h-12 w-12 mx-auto mb-4 opacity-50" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6v6m0 0v6m0-6h6m-6 0H6" />
                      </svg>
                      <p>Purchase your first WhatsApp number to get started</p>
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Support Tab */}
          <TabsContent value="support" className="space-y-8">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              <Card>
                <CardHeader>
                  <CardTitle>Create Support Ticket</CardTitle>
                </CardHeader>
                <CardContent>
                  <form onSubmit={handleSupportSubmit} className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="priority">Priority</Label>
                        <Select name="priority" defaultValue="medium">
                          <SelectTrigger data-testid="select-support-priority">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="low">Low</SelectItem>
                            <SelectItem value="medium">Medium</SelectItem>
                            <SelectItem value="high">High</SelectItem>
                            <SelectItem value="urgent">Urgent</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      <div>
                        <Label htmlFor="category">Category</Label>
                        <Select name="category" required>
                          <SelectTrigger data-testid="select-support-category">
                            <SelectValue placeholder="Select category" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="order">Order Support</SelectItem>
                            <SelectItem value="payment">Payment Issues</SelectItem>
                            <SelectItem value="account">Account Problems</SelectItem>
                            <SelectItem value="technical">Technical Issues</SelectItem>
                            <SelectItem value="other">Other</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                    <div>
                      <Label htmlFor="subject">Subject</Label>
                      <Input id="subject" name="subject" required data-testid="input-support-subject" />
                    </div>
                    <div>
                      <Label htmlFor="orderId">Order ID (optional)</Label>
                      <Input id="orderId" name="orderId" placeholder="#12345" data-testid="input-support-order-id" />
                    </div>
                    <div>
                      <Label htmlFor="message">Message</Label>
                      <Textarea id="message" name="message" rows={4} required data-testid="textarea-support-message" />
                    </div>
                    <Button type="submit" disabled={createSupportTicketMutation.isPending} data-testid="button-submit-support">
                      {createSupportTicketMutation.isPending ? <Loading size="sm" className="mr-2" /> : null}
                      Submit Ticket
                    </Button>
                  </form>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>My Support Tickets</CardTitle>
                </CardHeader>
                <CardContent>
                  {supportLoading ? (
                    <div className="flex justify-center py-4">
                      <Loading size="sm" />
                    </div>
                  ) : supportTickets && supportTickets.length > 0 ? (
                    <div className="space-y-4 max-h-80 overflow-y-auto">
                      {supportTickets.map((ticket: SupportTicket) => (
                        <div key={ticket.id} className="border border-border rounded-lg p-4">
                          <div className="flex items-center justify-between mb-2">
                            <span className="text-sm font-medium" data-testid={`text-ticket-${ticket.id}`}>#{ticket.id}</span>
                            <Badge variant={
                              ticket.status === 'open' ? 'destructive' :
                              ticket.status === 'in_progress' ? 'secondary' :
                              ticket.status === 'resolved' ? 'default' :
                              'outline'
                            } data-testid={`badge-ticket-status-${ticket.id}`}>
                              {ticket.status.replace('_', ' ')}
                            </Badge>
                          </div>
                          <p className="font-medium text-foreground mb-1">{ticket.subject}</p>
                          <p className="text-sm text-muted-foreground mb-2">{ticket.message.substring(0, 100)}...</p>
                          <div className="flex items-center justify-between text-xs text-muted-foreground">
                            <span>Priority: {ticket.priority}</span>
                            <span>{new Date(ticket.createdAt).toLocaleDateString()}</span>
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="text-center py-8 text-muted-foreground">
                      <p>No support tickets found.</p>
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
